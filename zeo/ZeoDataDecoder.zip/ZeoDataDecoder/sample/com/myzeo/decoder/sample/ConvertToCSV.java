/*-----------------------------------------------------------------------------
Copyright (c) 2010, Zeo, Inc. All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above 
      copyright notice, this list of conditions and the following 
      disclaimer in the documentation and/or other materials provided 
      with the distribution.

    * Neither the name of Zeo, Inc. nor the names of its contributors 
      may be used to endorse or promote products derived from this 
      software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ZEO, INC. BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
THE POSSIBILITY OF SUCH DAMAGE.
------------------------------------------------------------------------------*/
package com.myzeo.decoder.sample;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.TimeZone;

import com.myzeo.decoder.AlarmReason;
import com.myzeo.decoder.SleepStage;
import com.myzeo.decoder.WakeTone;
import com.myzeo.decoder.ZeoData;
import com.myzeo.decoder.ZeoDataDecoder;

/**
 * Sample code showing how to generate CSV output using the OpenDecoder library.
 * The CSV output by this class is adapted to closely match the CSV output by
 * the Export Data feature on mysleep.myzeo.com.
 */
public class ConvertToCSV {
    /** Date formatter used to output date/time objects. */ 
    private static final DateFormat DATE_TIME_FORMAT = new SimpleDateFormat("MM/dd/yyyy hh:mm");
    
    /** Date formatter used to output date objects. */
    private static final DateFormat DATE_FORMAT = new SimpleDateFormat("MM/dd/yyyy");
    
    /** CSV column headers */
    private static final String HEADERS[] = {
        "Sleep Date",
        "ZQ",
        "Total Z",
        "Time to Z",
        "Time in Wake",
        "Time in REM",
        "Time in Light",
        "Time in Deep",
        "Awakenings",
        "Start of Night",
        "End of Night",
        "Rise Time",
        "Alarm Reason",
        "Snooze Time",
        "Wake Tone",
        "Wake Window",
        "Alarm Type",
        "First Alarm Ring",
        "Last Alarm Ring",
        "First Snooze Time",
        "Last Snooze Time",
        "Set Alarm Time",
        "Morning Feel",
        "Sleep Graph",
        "Detailed Sleep Graph",
        "Firmware Version"
    };
    
    /**
     * Formats an AlarmReason as a String.
     * 
     * @param a an AlarmReason
     * @return a String representing the AlarmReason object's ordinal
     */
    private static String format(AlarmReason a) {
        return format(a.ordinal());
    }
    
    /**
     * Formats a byte array as a String.
     * 
     * @param b a byte array
     * @return a String representing the values in the byte array 
     */
    private static String formatHypnogram(byte b[]) {
        StringBuffer s = new StringBuffer();

        // strip off trailing zeroes
        int lastNonzeroIndex = 0;
        for (int i = 0; i < b.length; i++) {
            if (b[i] != 0) lastNonzeroIndex = i;
        }
        
        for (int i = 0; i < lastNonzeroIndex; i++) {
            switch (SleepStage.convert(b[i])) {
            case UNUSED:
                // skip the unused sleep stage label to match website CSV output 
                break;
                
            case DEEP_2:
                // show DEEP_2 as DEEP to match website CSV output
                b[i] = (byte) SleepStage.DEEP.ordinal();
                break;
                
            default:
                if (i > 0) s.append(' '); 
                s.append((char) (b[i] + '0'));
                break;
            }
        }
        
        return s.toString();
    }
    
    /**
     * Formats a calendar's date and time as a String.
     * 
     * @param c a calendar
     * @return a String representing the calendar's date object
     */
    private static String formatDateTime(Calendar c) {
        if (c == null) {
            return "";
        } else {
            // NOTE: The time returned by the calendar is intended to be 
            // displayed in GMT.  By default, Java converts it to the local
            // time zone.  We must manually set the calendar's time zone in 
            // order for the time to display correctly.
            c.setTimeZone(TimeZone.getTimeZone("GMT"));
            return DATE_TIME_FORMAT.format(c.getTime());
        }
    }
    
    /**
     * Formats a calendar's date as a String.
     * 
     * @param c a calendar
     * @return a String representing the calendar's date object
     */
    private static String formatDate(Calendar c) {
        if (c == null) {
            return "";
        } else {
            // NOTE: The time returned by the calendar is intended to be 
            // displayed in GMT.  By default, Java converts it to the local
            // time zone.  We must manually set the calendar's time zone in 
            // order for the time to display correctly.
            c.setTimeZone(TimeZone.getTimeZone("GMT"));
            return DATE_FORMAT.format(c.getTime());
        }
    }
    
    /**
     * Formats a 30-second epoch duration as a String representing a whole number
     * of minutes.
     * 
     * @param i an epoch duration
     * @return a String representing the epoch duration as a whole number of 
     * minutes
     */
    private static String formatEpoch(int i) {
        return Integer.toString((i + 1) / 2);
    }
    
    /**
     * Formats an integer as a String.
     * 
     * @param i an integer
     * @return a String representing the integer argument
     */
    private static String format(int i) {
        return Integer.toString(i);
    }
    
    /**
     * Formats a boolean as a String.
     * 
     * @param b a boolean
     * @return a String representing the boolean argument as "0" or "1"
     */
    private static String format(boolean b) {
        return b ? "1" : "0";
    }
    
    /**
     * Formats an WakeTone as a String.
     * 
     * @param t a WakeTone
     * @return a String representing the WakeTone object's ordinal
     */
    private static String format(WakeTone t) {
        return format(t.ordinal());
    }

    /**
     * Prints the list of ZeoData records to the specified PrintStream.
     * 
     * @param records a list of ZeoData records
     * @param out the output destination
     */
    private static void printRecordList(List<ZeoData> records, PrintStream out) { 
        for (int i = 0; i < HEADERS.length; i++) {
            if (i > 0) out.print(",");
            out.print(HEADERS[i]);
        }
        out.println();
        
        for (ZeoData r : records) {
            // Sleep Date
            out.print(formatDate(r.get_sleep_date()));
            out.print(",");
            
            // ZQ
            out.print(format(r.get_zq_score()));
            out.print(",");
            
            // Total Z
            out.print(formatEpoch(r.get_total_z()));
            out.print(",");
            
            // Time to Z
            out.print(formatEpoch(r.get_time_to_z()));
            out.print(",");
            
            // Time in Wake
            out.print(formatEpoch(r.get_time_in_wake()));
            out.print(",");
            
            // Time in REM
            out.print(formatEpoch(r.get_time_in_rem()));
            out.print(",");
            
            // Time in Light
            out.print(formatEpoch(r.get_time_in_light()));
            out.print(",");
            
            // Time in Deep
            out.print(formatEpoch(r.get_time_in_deep()));
            out.print(",");
            
            // Awakenings
            out.print(format(r.get_awakenings()));
            out.print(",");
            
            // Start of Night
            // 
            // NOTE:
            // The CSV export uses the hypnogram start time from
            // get_hypnogram_start_time(). This is the get_start_of_night_time()
            // value rounded down to the nearest 5 minute boundary and
            // corresponds to the first element of the hypnogram arrays. This is
            // used in the CSV export to simplify it by not exposing the 
            // difference between start of night and hypnogram start.
            out.print(formatDateTime(r.get_hypnogram_start_time()));
            out.print(",");
            
            // End of Night
            out.print(formatDateTime(r.get_end_of_night()));
            out.print(",");
            
            // Rise Time
            out.print(formatDateTime(r.get_rise_time()));
            out.print(",");
            
            // Alarm Reason 
            out.print(format(r.get_alarm_reason()));
            out.print(",");
            
            // Snooze Time
            out.print(format(r.get_snooze_time()));
            out.print(",");
            
            // Wake Tone
            out.print(format(r.get_wake_tone()));
            out.print(",");
            
            // Wake Window
            out.print(format(r.get_wake_window()));
            out.print(",");
            
            // Alarm Type
            out.print(format(r.get_zeo_wake_on()));
            out.print(",");
            
            // First Alarm Ring
            out.print(formatDateTime(r.get_alarm_ring()[0]));
            out.print(",");
            
            // Last Alarm Ring
            int numAlarmRings = r.get_alarm_ring().length;
            out.print((numAlarmRings > 1) ? 
                        formatDateTime(r.get_alarm_ring()[numAlarmRings-1]) :
                        "");
            out.print(",");
            
            // First Snooze Time
            out.print(formatDateTime(r.get_alarm_snooze()[0]));
            out.print(",");
            
            // Last Snooze Time 
            int numAlarmSnoozes = r.get_alarm_snooze().length;
            out.print((numAlarmSnoozes > 1) ?
                          formatDateTime(r.get_alarm_snooze()[numAlarmSnoozes-1]) : 
                          "");
            out.print(",");
            
            // Set Alarm Time
            out.print(formatDateTime(r.get_alarm_set_time()));
            out.print(",");
            
            // Morning Feel
            out.print(format(r.get_sleep_rating()));
            out.print(",");
            
            // Sleep Graph
            out.print(formatHypnogram(r.get_display_hypnogram()));
            out.print(",");
            
            // Detailed Sleep Graph
            out.print(formatHypnogram(r.get_base_hypnogram()));
            out.print(",");
            
            // Firmware Version
            out.print(format(r.get_id_sw()));
            out.println();
        }
    }
    
    /**
     * Reads the specified data file and parses it into a list of ZeoData 
     * objects.
     *     
     * @param file a Zeo data file
     * @return a list of ZeoData objects
     * 
     * @throws IOException if an error occurs opening or reading the data file
     */
    private static List<ZeoData> readList(File file) throws IOException {
        // open the input file as a file channel
        FileChannel fc = new FileInputStream(file).getChannel();
        
        // allocate a byte array to hold the entire input file
        byte data[] = new byte[(int) fc.size()];
        // wrap it in a byte buffer
        ByteBuffer in = ByteBuffer.wrap(data);
        
        // read the file data into the byte array
        fc.read(in);
        in.rewind();
        
        // set up the decoder
        ZeoDataDecoder decoder = new ZeoDataDecoder(in);
        
        // reduce records down to only records that comprise distinct nights
        decoder.reduce_records();
        
        // fill in is_nap and sleep_date information
        decoder.label_naps();
        
        return decoder.get_records();
    }
    
    public static void main(String args[]) {
        if (args.length != 1) {
            System.err.println("Usage: " + 
                               ConvertToCSV.class.getName() + 
                               " data_file_name");
            System.exit(-1);
        }
        
        try {
            List<ZeoData> data = readList(new File(args[0]));    
            printRecordList(data, System.out);
        } catch (IOException ex) {
            ex.printStackTrace(System.err);
        }
    }
}
